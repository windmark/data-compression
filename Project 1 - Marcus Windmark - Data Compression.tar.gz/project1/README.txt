Marcus Windmark, Oct 23 2014
Data Compression, National Taiwan Normal University


The class files are in ./out/production/project1/ and the follow commands can be run.
Encoding: java AdaptiveHuffmanEncode input_file output_file output_huffman_table_file
Decoding: java AdaptiveHuffmanDecode input_file output_file
