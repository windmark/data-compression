Marcus Windmark, Dec 25 2014
Data Compression, National Taiwan Normal University


The class files are in out/production/project2/ and the following commands can be run.

Encoding: java TransformImageEncode raw_file encoded_file

Decoding: java TransformImageDecode encoded_file decoded_file

SNR: java SignalToNoiseRatio original_file decoded_file
